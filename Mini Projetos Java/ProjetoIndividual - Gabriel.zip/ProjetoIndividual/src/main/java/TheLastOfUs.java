
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class TheLastOfUs {
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("Venha ver se você é realmente fã de The Last Of Us\n"
                + "\nEscolha uma das opções abaixo \n\n"
                + "1 - Saiba quantos zumbis cada pessoa pode matar \n"
                + "2 - É fã mesmo do jogo? \n"
                + "3 - Saiba quantos zumbis você conseguiria matar sozinho \n"
                + "4 - Sair");
        Integer valorEscolhe = leitor.nextInt();
        
        while (valorEscolhe < 1 || valorEscolhe > 4) {
            System.out.println("Escolha um número válido");
            valorEscolhe = leitor.nextInt();
        }
        
        switch (valorEscolhe) {
            case 1:
                System.out.println("Digite um número de pessoas");
                Integer numeroPessoas = leitor.nextInt();
                Integer numeroMatar = numeroPessoas * 4;
                System.out.println(String.format("%d pessoa/as poderiam matar "
                        + "%d zumbis", numeroPessoas, numeroMatar));
                break;
            case 2:
                System.out.println("Qual o nome da filha do Joel?");
                String resposta = leitor.next();
                
                if (!"Sarah".equals(resposta)) {
                    System.out.println("Resposta errada amigão");
                }
                else{
                    System.out.println("Parabéns, você realmente conhece esse "
                            + "jogo");
                }
                break;
            case 3:
                Integer numero = ThreadLocalRandom.current().nextInt(0,101);
                
                if (numero >= 0 && numero <= 10) {
                    System.out.println(String.format("Você mataria %d zumbis.\n"
                            + "Iniciante ainda pô, mas da para melhorar",
                            numero));
                }
                else if (numero > 10 && numero <= 30) {
                    System.out.println(String.format("Você mataria %d zumbis.\n"
                            + "Malandro, tu é o bichão mesmo em doido", 
                            numero));
                }
                else if (numero > 30 && numero <= 50) {
                    System.out.println(String.format("Você mataria %d zumbis.\n"
                            + "Maluco é brabo", numero));
                }
                else if (numero > 50 && numero <= 70) {
                    System.out.println(String.format("Você mataria %d zumbis.\n"
                            + "Ah não, é o Bryan", numero));
                }
                else if (numero > 70 && numero <= 100) {
                    System.out.println(String.format("Você mataria %d zumbis.\n"
                            + "O Jubileu está esquisito hoje, eu tenho medo", 
                            numero));
                }
                break;
            case 4:
                System.out.println("Até logo meu jovem");
                break;
            default:
                throw new AssertionError();
        }
    
}
}
