
import java.util.Scanner;

public class SistemaLivros {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Bem vindos queridos leitores! Selecione uma opção:\n 1 -- Calcular sua meta! \n 2 -- Validar seu objetivo! \n 3 -- Sugerir um livro para leitura! \n "
                + "4 -- Jogar 3 Perguntas!\n 5 -- Fechar o sistema! ");
        Integer opcaoSelecionada = scan.nextInt();

        while (opcaoSelecionada != 1 && opcaoSelecionada != 2 && opcaoSelecionada != 3 && opcaoSelecionada != 4 && opcaoSelecionada != 5) {
            System.out.println("Opção inválida! Selecione um número entre 1 e 5");
            opcaoSelecionada = scan.nextInt();
        }

        switch (opcaoSelecionada) {
            case 1:
                calcularObjetivoDeLeituraNoAno();
                break;
            case 2:
                validarObjetivoMaiorOuMenor();
                break;
            case 3:
                printarLivroSurpresa();
                break;
            case 4:
                jogarTresPerguntas();
                break;
            case 5:
                break;
        }

        System.out.println("Boas leituras! Finalizando o sistema...");

    }

    private static void jogarTresPerguntas() {
        Scanner scan = new Scanner(System.in);

        boolean jogarNovamente = true;

        while (jogarNovamente) {

            Integer pontuacao = 0;

            System.out.println("Bem vindo ao jogo das 3 perguntas!\n Vamos fazer 3 perguntas de verdadeiro ou falso, "
                    + "e você deve responder com o di­gito 1 -- Verdadeiro ou 2 -- Falso!\n"
                    + " Qualquer outro di­gito será uma resposta errada!");
            System.out.println("-- PERGUNTA 1 -- \n A BÃ­blia é o livro mais lido e mais vendido no mundo até hoje?");

            Integer resposta = scan.nextInt();
            if (resposta == 1) {
                pontuacao++;
            }

            System.out.println("-- PERGUNTA 2 -- \n O livro mais longo do mundo tem cerca de 9 609 000 caracteres e se chama 'Em Busca do Tempo Perdido'?"
                    + "\n 1 -- Verdadeiro ou 2 -- Falso!");
            resposta = scan.nextInt();
            if (resposta == 1) {
                pontuacao++;
            }

            System.out.println("-- PERGUNTA 3 -- \n A primeira Bienal do Livro de São Paulo ocorreu em 1950?"
                    + "\n 1 -- Verdadeiro ou 2 -- Falso!");
            resposta = scan.nextInt();
            if (resposta == 2) {
                pontuacao++;
            }

            String resultado = String.format("Parabén, você fez %d ponto(s)!!!\n Deseja jogar novamente?\n Responda com o di­gito 1 -- SIM 2 -- Não", pontuacao);
            System.out.println(resultado);
            Integer respostaJogarNovamente = scan.nextInt();

            jogarNovamente = respostaJogarNovamente == 1;
        }
    }

    private static void printarLivroSurpresa() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Não sabe o que ler? Deixa com a gente!\n Escolha um número de 1 a 10! Digite um número válido:");

        Integer numeroEscolhido = scan.nextInt();
        String livro = "";
        String descricao = "";

        switch (numeroEscolhido) {
            case 1:
                livro = "O Senhor dos Anéis";
                descricao = "O volume inicial de O Senhor dos Anéis ('A Sociedade do Anel'), lançado originalmente em julho de 1954, foi"
                        + " o primeiro grande épico de fantasia moderno, conquistando milhÃµes de leitores e se tornando o padrão de referência"
                        + " para todas as outras obras do gênero até hoje.";
                break;
            case 2:
                livro = "O Hobbit";
                descricao = "Prelúdio de 'O Senhor dos Anéis', 'O Hobbit' conquistou sucesso imediato quando foi publicado em 1937.";
                break;
            case 3:
                livro = "Jogos Vorazes";
                descricao = "Na abertura dos Jogos Vorazes, a organização não recolhe os corpos dos combatentes caí­dos e dá¡ tiros de canhão até o final. Cada tiro, um morto.";
                break;
            case 4:
                livro = "A Garota com a Tatuagem de Dragão";
                descricao = "Vem da Suécia um dos maiores êxitos no gênero de mistério dos últimos anos: a série Millennium - da qual "
                        + "o romance, 'Os homens que não amavam as mulheres', é o primeiro volume.";
                break;
            case 5:
                livro = "1984";
                descricao = "Winston, herói de 1984, Último romance de George Orwell, vive aprisionado na engrenagem totalitária de uma "
                        + "sociedade completamente dominada pelo Estado, onde tudo é feito coletivamente, mas cada qual vive sozinho.";
                break;
            case 6:
                livro = "Revolução dos Bichos";
                descricao = "Escrita em plena Segunda Guerra Mundial e publicada em 1945 depois de ter sido rejeitada por várias editoras,"
                        + " essa pequena narrativa causou desconforto ao satirizar ferozmente a ditadura stalinista numa época em que os soviéticos"
                        + " ainda eram aliados do Ocidente na luta contra o eixo nazifascista.";
                break;
            case 7:
                livro = "Código Limpo";
                descricao = "Mesmo um código ruim pode funcionar. Mas se ele não for limpo, pode acabar com uma empresa de desenvolvimento.";
                break;
            case 8:
                livro = "Arquitetura Limpa";
                descricao = "Com base em meio século de experiência nos mais variados ambientes de software, Uncle Bob indica as escolhas que você deve fazer e "
                        + "explica por que elas são cruciais para o seu sucesso.";
                break;
            case 9:
                livro = "Crepúsculo";
                descricao = "Crepúsculo poderia ser uma história comum, não fosse um elemento irresistí­vel: o objeto da paixão da protagonista é um vampiro.";
                break;
            case 10:
                livro = "As Crônicas de Nárnia";
                descricao = "Viagens ao fim do mundo, criaturas fantásticas e batalhas épicas entre o bem e o mal - o que mais um leitor poderia querer de um livro?";
                break;
        }

        String resposta = String.format("Nós recomendamos que leia '%s'.\n%s", livro, descricao);
        System.out.println(resposta);

    }

    private static void validarObjetivoMaiorOuMenor() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Vamos ver se o seu objetivo de leitura para este ano é maior que a meta (25% a mais que ano passado)."
                + "\n Quantos livros você leu ano passado? Digite um número válido:");
        Integer livrosLidosAnoPassado = scan.nextInt();
        System.out.println("\n Quantos livros você pretende ler este ano? Digite um número válido:");
        Integer livrosALerEsteAno = scan.nextInt();

        double metaDeLivros = livrosLidosAnoPassado * 1.25;
        Integer metaDeLivrosArredondado = (int) Math.round(metaDeLivros);

        String resposta = String.format("Seu objetivo está %s da meta!",
                livrosALerEsteAno < metaDeLivrosArredondado ? "ABAIXO" : "ACIMA");

        System.out.println(resposta);

    }

    private static void calcularObjetivoDeLeituraNoAno() {

        Scanner scan = new Scanner(System.in);

        System.out.println("Vamos calcular quantos livros você precisa ler para aumentar em 25% sua leitura no ano..."
                + "\n Quantos livros você leu ano passado? Digite um número válido:");

        Integer livrosLidosAnoPassado = scan.nextInt();

        double livrosALerEsteAno = livrosLidosAnoPassado * 1.25;
        Integer livrosALerEsteAnoArredondado = (int) Math.round(livrosALerEsteAno);
        String resposta = String.format("Você precisa ler %d livros este ano para atingir a meta!", livrosALerEsteAnoArredondado);
        System.out.println(resposta);

    }
}
