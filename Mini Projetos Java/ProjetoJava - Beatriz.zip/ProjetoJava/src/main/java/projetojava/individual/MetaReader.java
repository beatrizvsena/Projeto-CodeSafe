
package projetojava.individual;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class MetaReader {
 
     public static void main(String[] args) {

        System.out.println("Bem vindo ao MetaReader, seu organizador"
                + " de leituras!\n\n");
        Scanner opcao = new Scanner(System.in);
        System.out.println("Selecione uma opção a seguir: \n\n "
                + "1- Calcule sua leitura \n"
                + "2- Avalie o livro \n"
                + "3- Sorteie um livro \n"
                + "4- Sair");
        Integer opcaoEscolhida = opcao.nextInt();

        while (opcaoEscolhida > 4 && opcaoEscolhida < 10) {

            System.out.println("Digite uma opção válida");
            System.out.println(" \n Selecione uma opção a seguir: \n "
                    + "1- Calcule sua leitura \n"
                    + "2- Avalie o livro \n"
                    + "3- Sorteie um livro \n"
                    + "4- Sair");
            opcaoEscolhida = opcao.nextInt();
        }

        switch (opcaoEscolhida) {
            case 1:
                Scanner qtdPaginas = new Scanner(System.in);
                System.out.println("Digite a quantidade de páginas do livro");
                Integer qtdPaginasDigitada = qtdPaginas.nextInt();

                Scanner qtdTempo = new Scanner(System.in);
                System.out.println("Agora digite sua média de tempo livre "
                        + "(em minutos)");
                Integer qtdTempoDigitada = qtdTempo.nextInt();

                Integer calculo = qtdPaginasDigitada / qtdTempoDigitada;

           System.out.println(String.format("Você lerá um livro de %d páginas "
                     + "em aproximadamente %d dias se lendo %d páginas por dia",
                        qtdPaginasDigitada, calculo, qtdTempoDigitada));
                break;

            case 2:

                Scanner nomeLivro = new Scanner(System.in);
                System.out.println("Qual o nome do livro?");
                String nomeLivroDigitado = nomeLivro.nextLine();

                Scanner avaliacao = new Scanner(System.in);
                System.out.println("Quantas estrelas? \n \n "
                        + "10: Perfeito \n"
                        + "11: Muito bom! \n"
                        + "12: Bom \n "
                        + "13: Meio ruim! \n"
                        + "14: Ruim! ");
                Integer avaliacaoDigitada = avaliacao.nextInt();

                if (avaliacaoDigitada == 10) {
                    System.out.println(String.format("Você avaliou o livro %s "
                 + "como perfeito!", nomeLivroDigitado, avaliacaoDigitada));
                } else if (avaliacaoDigitada == 11) {
                    System.out.println(String.format("Você avaliou o livro %s "
               + "como muito bom!", nomeLivroDigitado, avaliacaoDigitada));
                } else if (avaliacaoDigitada == 12) {
                    System.out.println(String.format("Você avaliou o livro %s "
                        + "como bom!", nomeLivroDigitado, avaliacaoDigitada));
                } else if (avaliacaoDigitada == 13) {
                    System.out.println(String.format("Você avaliou o livro %s "
                 + "como meio ruim!", nomeLivroDigitado, avaliacaoDigitada));
                } else if (avaliacaoDigitada == 14) {
                    System.out.println(String.format("Você avaliou o livro %s "
                        + "como ruim!", nomeLivroDigitado, avaliacaoDigitada));
                }

                break;

            case 3:
                

                Integer sorteio = ThreadLocalRandom.current().nextInt(1, 3);

                if (sorteio == 1) {
                    System.out.println("Você deveria ler Six Of Crows");
                    break;
                }

                if (sorteio == 2) {
                    System.out.println("Você deveria ler Rastros de Sangue");
                }

                if (sorteio == 3) {
                    System.out.println("Você deveria ler The Atlas Six");
                }
                break;

            case 4:
                System.out.println(
                        "Sair");
                break;

        }
    }

}

  
