package com.mycompany.projetoindividual;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;


public class Index {
    
    public static void main(String[] args) {
        
        System.out.println("Bem-vindo(a) a MathEasy, um sistema para ajudar "
                + "alunos do Fundamental a aprederem matemática.");
        
        System.out.println("Digite um número de 1 a 4:");
    
         Scanner escolhaMenu = new Scanner(System.in);
         Integer numeroDigitado = escolhaMenu.nextInt();

            
            while (numeroDigitado > 4 ||numeroDigitado < 1) { 
                System.out.println("Número inválido, digite  entre 1 e 4:");
                numeroDigitado = escolhaMenu.nextInt();
            } 
           


                switch (numeroDigitado) {
                   case 1:
                     System.out.println("Você escolheu 1, digite números "
                             + "para somar");
                     System.out.println("Digite 0 para encerrar a soma");
                     Scanner valorDigitado = new Scanner(System.in);
                     Integer valor = valorDigitado.nextInt();

                     Integer somaValores = 0;

                     while (valor != 0) {
                       somaValores = somaValores + valor;
                       System.out.println("Digite outro número:");
                       valor = valorDigitado.nextInt();
                     }  
                      System.out.printf("A soma dos valores foi %d" , 
                              somaValores);
                     break;
                   case 2:
                     System.out.println("Você escolheu 2");
                     System.out.println("Digite um número para saber se é um "
                             + "número primo:");
                     Scanner primoAvaliado = new Scanner(System.in);
                     Integer avaliado = primoAvaliado.nextInt();

                     Integer qtdDivisoes = 0;

                     for (int cod = 1; cod <= avaliado; cod++)
                          if (avaliado%cod == 0){
                               qtdDivisoes++;
                           }
                         if (qtdDivisoes == 2){
                              System.out.printf("O número %d é primo" , 
                                      avaliado);
                          }else{
                             System.out.printf("O número %d não é primo" , 
                                      avaliado);
                         }
                     break;
                   case 3:
                     System.out.println("Você escolheu 3");
                     System.out.println("Digite um número para saber sua "
                             + "tabuada");
                     Scanner tabuadaDigitada = new Scanner(System.in);
                     Integer tabuada = tabuadaDigitada.nextInt();
                     for (int cod = 0; cod <= 10; cod++) {
                           System.out.println(tabuada + " X " + cod + " = " + 
                                   (tabuada*cod));
                     }
                     break;
                   case 4:
                     System.out.println("Você escolheu 4");
                     System.out.println("Obrigado pelo acesso!");
                     break;
                   /*case 5:
                     System.out.println("Você escolheu 5");
                     Integer codigo = ThreadLocalRandom.current().nextInt(1, 3);
                     System.out.println("Vamos jogar Cara ou Coroa! Escolha um "
                             + "número, 1 (cara) ou 2 (coroa):");
                       System.out.println("Digite 0 para encerrar o jogo.");
                     Scanner apostaScanner = new Scanner(System.in);
                     Integer placarPlayer = 0;
                     Integer placarComputador = 0;
                     
                     Integer aposta = apostaScanner.nextInt();
                     
                     while (aposta > 2 ||aposta < 1) { 
                            System.out.println("Número inválido, digite "
                                    + "entre 1 e 2:");
                            aposta = apostaScanner.nextInt();
                        } 
                     
                        
                          if (codigo != aposta){
                              System.out.printf("Computador venceu!");
                              placarComputador++;
                              codigo = ThreadLocalRandom.current().nextInt
                                (1, 3);
                              aposta = apostaScanner.nextInt();
                            }else{
                             System.out.printf("Você venceu!");
                             placarPlayer++;
                             codigo = ThreadLocalRandom.current().nextInt
                                (1, 3);
                             aposta = apostaScanner.nextInt();
                            }
                        
                        System.out.println("Placar: \n Computador: " + 
                                placarComputador + " Você: " + placarPlayer);
                    
                     
                     break;*/
                }    

            
            
         
        
    }
    
}